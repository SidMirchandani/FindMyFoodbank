zipcode_list = {'08820' : 'Mt. Zion U.F. Bapist Church', 
'08830' : 'St. Cecelia Church', '07063': 'The Salvation Army', '07060': 'The First Unitarian Society of Plainfield & Bianca Flowers, Inc', '11205': "Grace's Kitchen"}
user_zipcode = input('Input zipcode: ')
if user_zipcode in zipcode_list:
  if ' & ' in zipcode_list[user_zipcode]:
    print ('The foodbanks ' + zipcode_list[user_zipcode] + ' are nearby.')
  else:
    print ('The foodbank ' + zipcode_list[user_zipcode] + ' is nearby.')
else:
  print ('There is no food bank in your area. Perhaps check a nearby zip code instead.')